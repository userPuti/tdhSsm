create
    definer = root@localhost procedure test4()
BEGIN

DECLARE i INT; # 申明变量

SET i = 5; # 变量赋值

WHILE i<300 DO # 结束循环的条件: 当i大于5时跳出while循环

INSERT INTO t_user VALUES(i, 'bbbb', 'abcdef', '09_00003-2', '32010001', '19971123',  '2022-3-8', '1', 3); # 往test表添加数据

SET i = i+1; # 循环一次,i加1

END WHILE; # 结束while循环

END;

